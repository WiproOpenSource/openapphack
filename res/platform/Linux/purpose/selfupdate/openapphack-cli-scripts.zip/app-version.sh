#!/bin/bash


function __apptool_version {
	echo "OpenAppHack CLI ${OPENAPPHACK_VERSION}"
}
