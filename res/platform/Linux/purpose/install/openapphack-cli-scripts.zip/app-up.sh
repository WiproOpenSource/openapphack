#!/bin/bash

function __apptool_up {
		vagrant up
}
