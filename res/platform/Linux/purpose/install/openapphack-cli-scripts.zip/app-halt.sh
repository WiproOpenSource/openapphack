#!/bin/bash

function __apptool_halt {
		vagrant halt
}
