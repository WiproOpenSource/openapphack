#!/bin/bash

function __apptool_destroy {
		vagrant destroy
}
