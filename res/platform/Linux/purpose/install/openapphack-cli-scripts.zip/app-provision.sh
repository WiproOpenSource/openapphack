#!/bin/bash

function __apptool_provision {
		vagrant provision
}
